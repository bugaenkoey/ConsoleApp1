﻿
namespace HouseBuilding
{
    public enum OrderBuilder
    {
        /*
        Empty,
        Basement,
        Wall,
        Window,
        Door,
        Roof
        */

        Empty,
        Basement,
        Wall,
        Roof,
        Window,
        Door

       
    }
}
