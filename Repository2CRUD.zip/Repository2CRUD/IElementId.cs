﻿namespace Repository2CRUD
{
    public interface IElementId
    {
        public int Id { get; set; }
    }
}